package com.izforge.izpack.panels;

import java.util.List;

import com.coi.tools.os.win.MSWinConstants;
import com.izforge.izpack.adaptator.IXMLElement;
import com.izforge.izpack.installer.AutomatedInstallData;
import com.izforge.izpack.installer.InstallerException;
import com.izforge.izpack.installer.PanelAutomation;
import com.izforge.izpack.installer.PanelAutomationHelper;
import com.izforge.izpack.parser.RegistryKey;
import com.izforge.izpack.util.os.RegistryDefaultHandler;
import com.izforge.izpack.util.os.RegistryHandler;

public class RegistryReaderPanelAutomationHelper extends PanelAutomationHelper implements PanelAutomation {

  @Override
  public void makeXMLData(AutomatedInstallData installData, IXMLElement panelRoot) {
    //
  }

  @Override
  public void runAutomated(AutomatedInstallData installData, IXMLElement panelRoot) throws InstallerException {
    try {
      RegistryHandler rh = RegistryDefaultHandler.getInstance();
      rh.setRoot(MSWinConstants.HKEY_LOCAL_MACHINE);
      List<RegistryKey> keys = RegistryReaderPanel.readSpec(RegistryReaderPanel.SPEC_FILE_ID);
      for (RegistryKey key : keys) {
        String variableValue = key.getDefaultValue();

        if (rh.valueExist(key.getKey(), key.getName())) {
          variableValue = rh.getValue(key.getKey(), key.getName()).getStringData();
        }

        installData.setVariable(key.getVariable(), variableValue);
      }
    } catch (Exception e) {
      e.printStackTrace();
      emitError("Error", e.getMessage());
    }
  }
}