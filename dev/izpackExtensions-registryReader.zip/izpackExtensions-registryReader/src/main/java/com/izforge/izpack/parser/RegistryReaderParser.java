package com.izforge.izpack.parser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.izforge.izpack.adaptator.IXMLElement;
import com.izforge.izpack.adaptator.IXMLParser;
import com.izforge.izpack.adaptator.impl.XMLParser;

public class RegistryReaderParser {

  enum Elements {
    REGISTRY("registry"), KEY("key"), NAME("name"), DEFAULT_VALUE("default"), VARIABLE("variable");
    
    private String name;
    
    Elements(String name) {
      this.name = name;
    }
    
    public String getName() {
      return name;
    }
  }
  
  public static List<RegistryKey> parse(InputStream is) throws Exception {
    List<RegistryKey> keys = new ArrayList<RegistryKey>();
    
    String xml = inputStreamToString(is);
    
    IXMLParser parser = new XMLParser();
    IXMLElement rootEl = parser.parse(xml);

    Vector<IXMLElement> registryEls = rootEl.getChildrenNamed(Elements.REGISTRY.getName());
    Iterator<IXMLElement> it = registryEls.iterator();
    while (it.hasNext()) {
      IXMLElement registryEl = it.next();

      String key = registryEl.getAttribute(Elements.KEY.getName());
      String name = registryEl.getAttribute(Elements.NAME.getName());
      String defaultValue = registryEl.getAttribute(Elements.DEFAULT_VALUE.getName());
      String variable = registryEl.getAttribute(Elements.VARIABLE.getName());
      keys.add(new RegistryKey(key, name, defaultValue, variable));
    }
    
    return keys;
  }
  
  private static String inputStreamToString(InputStream is) throws Exception{
    StringBuilder sb = new StringBuilder();
    String line;

    try {
      BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
      while ((line = reader.readLine()) != null) {
        sb.append(line).append("\n");
      }
    } finally {
      is.close();
    }
    return sb.toString();
  }
}