package com.izforge.izpack.panels;

import java.io.InputStream;
import java.util.List;

import com.coi.tools.os.win.MSWinConstants;
import com.izforge.izpack.installer.InstallData;
import com.izforge.izpack.installer.InstallerFrame;
import com.izforge.izpack.installer.IzPanel;
import com.izforge.izpack.installer.ResourceManager;
import com.izforge.izpack.parser.RegistryKey;
import com.izforge.izpack.parser.RegistryReaderParser;
import com.izforge.izpack.util.os.RegistryDefaultHandler;
import com.izforge.izpack.util.os.RegistryHandler;

/**
 * Reads registry keys defined in registryReaderSpec.xml file. When key is found in registry,
 * it  
 * 
 * Currently intended to be used only once. If you need to have two panels 
 * in the same installation, take a look how <code>UserInputPanel</code> deals with 
 * that using <code>instanceNumber</code> and <code>instanceCount</code>.
 * 
 * @author Maksim Sorokin
 */
public class RegistryReaderPanel extends IzPanel {

  private static final long serialVersionUID = -2686831922771063920L;
  
  static final String SPEC_FILE_ID = "registryReaderSpec.xml";
  
  public RegistryReaderPanel(InstallerFrame parent, InstallData idata) {
    super(parent, idata);
  }
  
  @Override
  public void panelActivate() {
    try {
      RegistryHandler rh = RegistryDefaultHandler.getInstance();
      rh.setRoot(MSWinConstants.HKEY_LOCAL_MACHINE);
      List<RegistryKey> keys = readSpec(SPEC_FILE_ID);
      for (RegistryKey key : keys) {
        String variableValue = key.getDefaultValue();

        if (rh.valueExist(key.getKey(), key.getName())) {
          variableValue = rh.getValue(key.getKey(), key.getName()).getStringData();
        }
        
        idata.setVariable(key.getVariable(), variableValue);
      }
    } catch (Exception e) {
      e.printStackTrace();
      emitError("Error", e.getMessage());
    }
    
    parent.skipPanel();
  }
  
  static List<RegistryKey> readSpec(String specFileID) throws Exception {
    InputStream is = ResourceManager.getInstance().getInputStream(specFileID);
    return RegistryReaderParser.parse(is);
  }
}