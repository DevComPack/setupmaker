Vaadin QuickTickets Dashboard Demo
==================================

Sources for the official Vaadin desktop browser demo application: http://demo.vaadin.com/dashboard

![QuickTickets Dashboard](https://vaadin.com/image/image_gallery?uuid=0333a002-1e66-43f4-b127-b7da911a3cb3&groupId=10187&t=1359053559577)

To run
==
Run the Maven install target and deploy the resulting WAR-file to your server.


Licenses
==
The source code is released under Apache 2.0.

The application uses a couple of add-ons:
 * Vaadin Charts, Commercial Vaadin Addon License: https://vaadin.com/license/cval-2.0
 * Vaadin Calendar, Apache 2.0
 * CSSInject, Apache 2.0
